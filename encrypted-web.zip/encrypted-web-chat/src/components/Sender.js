import React, { useState } from "react";
import generateKeyPair from "../lib/generateKeyPair";
import deriveKey from "../lib/deriveKey";
import encrypt from "../lib/encrypt";
import decrypt from "../lib/decrypt";

var parDeLlaves;
var derivedKey;
var iv;
export default (props) => {
  const [PubKBack, setPubKBack] = useState("");
  const [plainText, setPlainText] = useState("");
  const [encryptedText, setEncryptedText] = useState("");

  const GenerarKey = async function() {
      iv = window.crypto.getRandomValues(new Uint8Array(16)); 
      parDeLlaves = await generateKeyPair();
      console.log(parDeLlaves);
      const mostrarParDeLlaves = document.getElementById("Llave");
      mostrarParDeLlaves.innerHTML = JSON.stringify(parDeLlaves);
      return parDeLlaves;
  }
  var PEM = {};
  PEM._toUrlSafeBase64 = function (u8) {
    //console.log('Len:', u8.byteLength);
    return Buffer.from(u8).toString('base64')
      .replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
  };

  var OBJ_ID_EC_384 = '06 05 2B81040022'.replace(/\s+/g, '').toLowerCase();
  function parseEcPub(u8, jwk) {
  
    let ci = 16 + OBJ_ID_EC_384.length/2;
    let len = 48;
  
    var c = u8[ci];
    var xi = ci + 1;
    var x = u8.slice(xi, xi + len);
    var yi = xi + len;
    var y;
    console.log(c)
    if (0x04 === c) {
      y = u8.slice(yi, yi + len);
    } else if (0x02 !== c) {
      throw new Error("not a supported EC private key");
    }
    console.log("x: ", x);
    console.log("y: ", y);
    return {
      kty: jwk.kty
    , crv: jwk.crv
    , x: PEM._toUrlSafeBase64(x)
    //, xh: x
    , y: PEM._toUrlSafeBase64(y)
    //, yh: y
    };
  }
  var publicKeyBack = {};
  function parsePubPEMtoJWK(){
    let pem = PubKBack;
    var jwk = { kty: 'EC', crv: "P-384", x: null, y: null };
    let u8 = new Uint8Array([...atob(pem)].map(c => c.charCodeAt(0)));
    publicKeyBack = parseEcPub(u8, jwk)
    console.log(publicKeyBack);  
    let mostrarPublicKeyBack = document.getElementById("mostrarPBK");
    mostrarPublicKeyBack.innerHTML = JSON.stringify(publicKeyBack);
  };
  function convertArrayBufferToHexaDecimal(buffer) 
  {
    var data_view = new DataView(buffer)
    var iii, len, hex = '', c;

    for(iii = 0, len = data_view.byteLength; iii < len; iii += 1) 
    {
        c = data_view.getUint8(iii).toString(16);
        if(c.length < 2) 
        {
            c = '0' + c;
        }

        hex += c;
    }

    return hex;
  }
  
  async function generarDeriveKey() {
    console.log(publicKeyBack);
    console.log(parDeLlaves.privateKeyJwk);
    var secretToString;
    derivedKey = await deriveKey(
      publicKeyBack,
      parDeLlaves.privateKeyJwk
    );
    window.crypto.subtle.exportKey('raw',derivedKey).then((exportedKey) => {
      secretToString = convertArrayBufferToHexaDecimal(exportedKey);
      console.log(secretToString);
      console.log(derivedKey);
      let mostrarMiSecreta = document.getElementById("derivedd");
      mostrarMiSecreta.innerHTML = secretToString
    });
  }
  
  async function encriptarTexto() {
    console.log(iv);
    let textoEncriptado = await encrypt(plainText, derivedKey, iv);
    let mostrarTextoEncriptado = document.getElementById("encryptedText");
    mostrarTextoEncriptado.innerHTML = textoEncriptado;
  }

  async function descencriptarTexto() {
    let textoDescencriptado = await decrypt(encryptedText, derivedKey, iv);
    console.log(textoDescencriptado);

    let mostrarTextoEncriptado = document.getElementById("decryptedText");
    mostrarTextoEncriptado.innerHTML = textoDescencriptado;
  }
  const ECKey = require('ec-key');
  async function parseJWKToPEM() {
    var key = new ECKey(parDeLlaves.publicKeyJwk);
    console.log(key);
    console.log(key.toString());
    let mostrarPEM = document.getElementById("llavePEM");
    mostrarPEM.innerHTML = key.toString();
  }
  return (
    <div>
      <div class="Boton">
          <button onClick={GenerarKey}>Generar llave</button>
      </div>
      <h2>Par de llave: </h2>
      <div class="Llave">
          <p id="Llave"></p>
      </div>
      
      <hr/>
      <h2>Generar JWK</h2>
      
      <div class="JDW">
        <label>Ingresa tu llave publica</label>
        <input value={PubKBack} onChange={(e) => setPubKBack(e.target.value)}/>
        <button onClick={parsePubPEMtoJWK}>Generar JWK</button>
        <p id="mostrarPBK"></p>
      </div>
      <hr/>
      <div class= "Derive">
        <h2>Derive Key</h2>
        <button onClick={generarDeriveKey}>Generar Derive Key</button>
        <p id="derivedd"></p>
      </div>
      <hr/>
      <h2>Encrypt</h2>
      <div class="Encrypt">
        <input value={plainText} onChange={(e) => setPlainText(e.target.value)}/>
        <button onClick={encriptarTexto}>Encriptar Texto</button>
        <h3>Texto Encriptado: </h3>
        <p id="encryptedText"></p>
      </div>
      <hr/>
      <h2>Decrypt</h2>
      <div class="Decrypt">
        <input value={encryptedText} onChange={(e) => setEncryptedText(e.target.value)}/>
        <button onClick={descencriptarTexto}>Descencriptar Texto</button>
        <h3>Texto Descencriptado: </h3>
        <p id="decryptedText"></p>
      </div>
      <hr/>
      <h2>Transformar JWK a PEM</h2>
      <div class="JwkToPem">
        <button onClick={parseJWKToPEM}>Generar PEM apartir de la llave publica en JWK</button>
        <p id="llavePEM"></p>
      </div>
  </div>
  );
};
